<?php

return [
    'server_key' => env('FIREBASE_SERVER_KEY'), // Clave del servidor obtenida de Firebase Console
];
