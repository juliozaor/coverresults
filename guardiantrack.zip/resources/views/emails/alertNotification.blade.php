<!DOCTYPE html>
<html>
<head>
    <title>Alerta de Dispositivo</title>
</head>
<body>
    <p>{{ $messageContent }}</p>
</body>
</html>
