<!DOCTYPE html>
<html>
<head>
    <title>Your Password</title>
</head>
<body>
    <p>Hello,</p>
    <p>Your password is: <strong>{{ $temporaryPassword }}</strong></p>
    <p>Thank you!</p>
</body>
</html>
